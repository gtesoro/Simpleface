package simpleface;

public class SimpleAccelerometer {
	
	private RDMAccelerometer RDM;
	
	private int intTolerance = 10;
	
	public SimpleAccelerometer (){
		RDM = new RDMAccelerometer();
	}
	
	public boolean isMoving(){
		
		//Assume still position
		boolean bResult = false;
		
		//Check incs of the axis in order to know if the wiimote is still or not
		if ((RDM.getIncX() >= 0 + intTolerance) || (RDM.getIncX() <= 0 - intTolerance)){
			bResult = true;
		}
		if ((RDM.getIncY() >= 0 + intTolerance) || (RDM.getIncY() <= 0 - intTolerance)){
			bResult = true;
		}
		if ((RDM.getIncZ() >= 0 + intTolerance) || (RDM.getIncZ() <= 0 - intTolerance)){
			bResult = true;
		}
		return bResult;
	}
	
	public boolean isRollingRight(){
		
		//Assume not rolling
		boolean bResult = false;
		
		//Check X axis inc
		if (RDM.getIncX() >= 0 + intTolerance){
			//Check if the rest of axis are still
			if ((RDM.getIncY() <= 0 + intTolerance) || (RDM.getIncY() >= 0 - intTolerance)){
				if ((RDM.getIncZ() <= 0 + intTolerance) || (RDM.getIncZ() >= 0 - intTolerance)){
					bResult = true;
				}
			}
		}
		
		return bResult;
	}
	public boolean isRollingLeft(){
		
		//Assume not rolling
		boolean bResult = false;
		
		//Check X axis inc
		if (RDM.getIncX() <= 0 - intTolerance){
			//Check if the rest of axis are still
			if ((RDM.getIncY() <= 0 + intTolerance) || (RDM.getIncY() >= 0 - intTolerance)){
				if ((RDM.getIncZ() <= 0 + intTolerance) || (RDM.getIncZ() >= 0 - intTolerance)){
					bResult = true;
				}
			}
		}
		
		return bResult;
	}
	
	public void setTolerance(int intNewTolerance){
		
		this.intTolerance = intNewTolerance;
		
	}
	

}
