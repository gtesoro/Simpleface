package simpleface;

public class RDMAccelerometer {
	
	RDXAccelerometer wiimote;
	
	public RDMAccelerometer (){
		wiimote = new RDXAccelerometer();	
	}
	public int getIncX(){
		return wiimote.getActX() - wiimote.getLastX();
	}
	public int getIncY(){
		return wiimote.getActY() - wiimote.getLastY();
	}
	public int getIncZ(){
		return wiimote.getActZ() - wiimote.getLastZ();
	}
	public int getX(){
		return wiimote.getActX();
	}
	public int getY(){
		return wiimote.getActY();
	}
	public int getZ(){
		return wiimote.getActZ();
	}
}
