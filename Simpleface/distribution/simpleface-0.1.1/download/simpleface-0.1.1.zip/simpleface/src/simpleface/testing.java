package simpleface;


public class testing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Accelerometer myAcc;
		
		myAcc = new Accelerometer();
		
		myAcc.getPitchDelta();
		
		
	}

}
